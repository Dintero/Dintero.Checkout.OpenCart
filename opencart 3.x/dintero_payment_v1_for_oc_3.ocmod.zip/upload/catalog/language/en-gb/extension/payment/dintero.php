<?php
// Text
$_['text_title']	= 'Dintero';
$_['text_testmode']	= 'Warning: The payment gateway is in \'Test Mode\'. Your account will not be charged.';
$_['text_total']	= 'Shipping, Handling, Discounts & Taxes';